<?php
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
    
    require '../model/userdata.php';
    require '../connection/dbconnection.php';

    if($_SERVER["REQUEST_METHOD"] == "POST"){
        $username = $_POST["username"];
        $password = $_POST["password"];

        $db = new Db();

        $usernamesql = new Userdata();
        $result = $usernamesql->signin($username,$password); 
        if($result == 1){
            echo "<script>alert('please enter correct username and password')</script>";
            echo '<script>window.location.replace("../php/signin.php");</script>';
        }else{
            echo '<script>window.location.replace("../index.php");</script>';
         }
        // echo $result;
        // die();
        //  header('location: ../php/signin.php?result='.$result); 
        //  exit; 
    }else{
        echo '<script>window.location.replace("../php/signin.php");</script>';
    }
?>
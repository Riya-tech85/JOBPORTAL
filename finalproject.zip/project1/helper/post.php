<?php
session_start();
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
    require '../connection/dbconnection.php';
    require '../model/userdata.php';
    require '../model/postdata.php';

    $db = new Db();

    $userdata = new Userdata();
    $sqlpost1 = $userdata->getuserid();

    $postdata = new Postdata();
  
    if($_SERVER["REQUEST_METHOD"] == "POST"){
        $employername = $sqlpost1['full_name'];
        $joblocation = $_POST["joblocation"];
        $jobtitle = $_POST["jobtitle"];
        $jobemail = $sqlpost1['user_email'];
        $publish = 0 ;

        $filename=$_FILES['image']['name'];
        $tempname=$_FILES['image']['tmp_name'];
        $folder="../picture/".$filename;
        move_uploaded_file($tempname,$folder);
        
        $record = $postdata->getRecord();

            foreach($record as $x => $y){
                if($jobtitle === $y['employer_jobtitle'] && $jobemail === $y['employer_email'] && $joblocation === $y['employer_location']){
                    echo "<script>alert('You already post this job')</script>";
                    $flag = 1;
                    // header("location: ../php/postjob.php?result=1");
                    echo '<script>window.location.replace("../php/postjob.php");</script>';
                }
            }
            if(empty($flag)){
                $postdata->postjob($employername,$joblocation,$jobtitle,$jobemail,$publish,$folder);
                $fetch = $postdata->getpostid();
                $array = http_build_query($fetch);
                // print_r($array);
                // die();
                header("location: ../php/postjob.php?{$array}");
            }
    }else{
        echo '<script>window.location.replace("../php/postjob.php");</script>';
    }
    ?>
<?php
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
    session_start();
    require '../connection/dbconnection.php';
    require '../model/postdata.php';
    require '../model/applyjob.php';

    $db =new Db();
    $postdata = new Postdata();
    $applyjob = new Applyjob();
    $sessuser = $_SESSION['username'];
    $_SESSION['num'] = "";

    $fetchapplydata = $applyjob->getapplyrecord();
    
    if($_SERVER["REQUEST_METHOD"] == "POST" && !empty($_POST['custId2'])){
        $id = $_POST['custId2'];
        $fetch = $postdata->getpostid1($id);
        $employeetitle = $fetch['employer_jobtitle'];
        $employeemail = $fetch['employer_email'];
        
        // foreach($fetchapplydata as $x => $y){
        //     if($employeetitle == $y['employer_title'] && $employeemail == $y['employee_email'] && $sessuser == $y['empoyee_name']){
        //         $_SESSION['num'] = 'You already registered this job';
        //         // echo "<script>alert('You already registered this job')</script>";
        //         $flag = 1;
        //         // echo '<script>window.location.replace("../index.php");</script>';
        //     }
        // }
        if(empty($flag)){
            $employeelocation = $fetch['employer_location'];
            $employeename = $fetch['employer_name'];
            $image = $fetch['img'];
            
            $result = $applyjob->insert($sessuser,$employeename,$employeemail,$employeelocation,$employeetitle,$image);
            // if($result == 1){
            //     $_SESSION['num'] = 'successfully registered';
            //     // echo "<script>alert('successfully registered')</script>";
            //     // echo '<script>window.location.replace("../helper/applypage.php");</script>';
            // }
            // else{
            // }
        }          
    }
    if($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['search'])){
        $search = $_POST['search'];
        $fetchapplydata = $applyjob->search($search);
        $array1 = http_build_query($fetchapplydata);
        header("location: ../php/applyjob.php?{$array1}");
    }else{
        $fetchapplydata = $applyjob->getapplyrecord();
        $array1 = http_build_query($fetchapplydata);
        header("location: ../php/applyjob.php?{$array1}");
    }
?>


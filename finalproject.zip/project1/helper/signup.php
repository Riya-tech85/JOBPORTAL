<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
    require '../model/userdata.php';
    require '../connection/dbconnection.php';
   
    if($_SERVER["REQUEST_METHOD"] == "POST"){
        $username = $_POST["username"];
        $fullname = $_POST["name"];
        $email = $_POST["email"];
        $password = $_POST["password"];
        $usertype = $_POST["usertype"];

        $db = new Db();

        $usernamesql = new Userdata();
        $result = $usernamesql->signupdata($username,$email);
            
        if(!empty($result)){
                    if($username == $result['user_name']){
                        echo "<script>alert('This username is already used .')</script> ";
                        echo "<script>window.location.replace('../php/signup.php');</script>";
                    }
                    else{
                        echo "<script>alert('This email is already used .')</script> ";
                        echo "<script>window.location.replace('../php/signup.php');</script>";
                    }
            }
        else{
            $fetch = $usernamesql->insertuserdata($username,$fullname,$usertype,$password,$email);
            if($fetch == 1){
                echo "<script>alert('data successfully added')</script>";
                echo '<script>window.location.replace("../index.php");</script>';
            }
        }
    }
    else{
        echo "<script>window.location.replace('../php/signup.php');</script>";
    }
?>
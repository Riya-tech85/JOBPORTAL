<?php
    ini_set('display_errors', 1); error_reporting(E_ALL);
    ini_set('display_startup_errors', 1);

// http://localhost/project1/index.php?p=userhelper
    // $smarty = new Smarty();
    
    // $pagefall = $_GET['p']??null;

    // if($pagefall) {
    //     require_once $pagefall.'.php';  
    // } else {
    //     require_once 'php/home.php';
    // }

    echo "<script>window.location.replace('php/home.php');</script>";
?>
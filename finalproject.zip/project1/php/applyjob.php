<?php
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    error_reporting(E_ALL);
    session_start();
    require '../smarty/libs/Smarty.class.php';

    $smarty = new Smarty;
    
    if($_SESSION){
        $sessuser = $_SESSION['username'];
        $smarty->assign('username',$sessuser);
    }
    if(isset($_SESSION['num'])){
        $num = $_SESSION['num'];
        $smarty->assign('num',$num);
    }
    $smarty->assign('applydata',$_GET);

    $smarty->display('applypage.tpl');
?>


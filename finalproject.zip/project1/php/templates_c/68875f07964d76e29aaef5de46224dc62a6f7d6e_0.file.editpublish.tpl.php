<?php
/* Smarty version 4.3.1, created on 2023-06-02 17:28:05
  from '/home/users/riya.singh/www/html/project1/php/templates/editpublish.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_6479d94d4b9a59_00232683',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '68875f07964d76e29aaef5de46224dc62a6f7d6e' => 
    array (
      0 => '/home/users/riya.singh/www/html/project1/php/templates/editpublish.tpl',
      1 => 1685707044,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_6479d94d4b9a59_00232683 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"><?php echo '</script'; ?>
>
    <link rel = "stylesheet" href = "../css/signin.css">
    <title>EditPublishPost</title>
</head>
<body>
    <nav class = "navbar navbar-expand-sm ">
        <div class="container">
            <span class="navbar-brand">
                <img src=""><span class ="text-white">JOBSTAKE</span>
            </span>
            <span class=" justify-content-end"><a href = "../index.php"><button>BACK</button></a></span>
        </div>
    </nav>
    <div class = "mt-2 mb-2" style = "float: right; margin-right : 5%;">

    <!-- Button trigger modal -->

        <button type="button" class="btn editbutton" data-bs-toggle="modal" data-bs-target="#exampleModal">
            EDIT POSTJOB
        </button>
        <form method = 'post' action = "../helper/editpublish.php" >
            <input type="hidden" name="custId" value="<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
">
            <input class = "editbutton" type = "submit" value = "PUBLISH POST" style = "background-color : orange;" >
        </form> 
    </div>
    <div class = "formcontainer p-3 d-flex mt-5">
        <div><img src = '<?php echo $_smarty_tpl->tpl_vars['image']->value;?>
' width = "100px" height = "100px"></div>
        <div class = "container" >
            <b style = "color : blue;"><?php echo $_smarty_tpl->tpl_vars['jobtitle']->value;?>
</b>
            <br>
            Posted by - <?php echo $_smarty_tpl->tpl_vars['employername']->value;?>
<br>
            Posted on - <?php echo $_smarty_tpl->tpl_vars['date']->value;?>
<br>
            Location - <?php echo $_smarty_tpl->tpl_vars['joblocation']->value;?>
 <br>
            Contact Email - <?php echo $_smarty_tpl->tpl_vars['jobemail']->value;?>

        </div>
    </div>
    <hr style = "margin: 3% 25%;">
    <div id = "text">You can edit your post only here before publishing it.</div> 

    <!-- modal -->

    <div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
        <form method = "post" action ="../helper/editpublish.php" enctype="multipart/form-data"><div class = "mb-3">
                <label for = "location" class = "form-label">Location: </label><br>
                <input type = "text" class = "form-control no-outline" id = "location1" value = "<?php echo $_smarty_tpl->tpl_vars['joblocation']->value;?>
" name = "joblocation">
            </div>
            <div class = "mb-3">
                <label for = "job title" class = "form-label">Job Title: </label><br>
                <input type = "text" class = "form-control no-outline" id = "title1" value = "<?php echo $_smarty_tpl->tpl_vars['jobtitle']->value;?>
" name = "jobtitle" >
            </div>
            <div class = "mb-3">
                <input type = "file" name = "image" value = "" >
            </div>
            <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
        <button type="submit" id = "btn" class="btn btn-primary">Save changes</button>
      </div>
      </div></form>
      
    </div>
  </div>
</div>
</body>

</html><?php }
}

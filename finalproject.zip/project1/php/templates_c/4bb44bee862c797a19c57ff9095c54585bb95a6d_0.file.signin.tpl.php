<?php
/* Smarty version 4.3.1, created on 2023-06-05 10:09:04
  from '/home/users/riya.singh/www/html/project1/php/templates/signin.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_647d66e89dbd13_65202999',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '4bb44bee862c797a19c57ff9095c54585bb95a6d' => 
    array (
      0 => '/home/users/riya.singh/www/html/project1/php/templates/signin.tpl',
      1 => 1685939942,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_647d66e89dbd13_65202999 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Signin</title>
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
        <?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"><?php echo '</script'; ?>
>
        <link rel = "stylesheet" href = "../css/signin.css">
    </head>
    <body >
        <nav class = "navbar navbar-expand-sm ">
                <div class="container">
                    <span class="navbar-brand">
                        <img src=""><span class ="text-white">JOBSTAKE</span>
                    </span>
                    <span class=" justify-content-end"><a href = "../index.php"><button>BACK</button></a></span>
                </div>
            </nav>
            <div class = "formcontainer">
            <form method = "post" action = "../helper/signin.php" class  = " container">
                <h1 style= "text-align: center;">SIGN IN</h1>
                <div class = "mb-3 mt-3 ">
                    <label for ="username" class="form-label">Username: </label><br>
                    <input type = "username" class = "form-control no-outline" id = "username1" placeholder = "Enter username" name = "username" required >
                </div>
                <div class = "mb-3 ">
                    <label for = "pwd" class = "form-label">Password:</label><br>
                    <input type = "password" class = "form-control no-outline" placeholder = "Enter password" id = "pwd" name = "password" required>
                </div>
                
                <button type="submit" class="btn btn-primary">Login</button>
                <p>Don't have an account <a href="../php/signup.php">Sign-up Here</a></p>
            </form>
            </div>
            <?php echo '<script'; ?>
 src="../js/signinvalidation.js"><?php echo '</script'; ?>
>
    </body>
</html><?php }
}

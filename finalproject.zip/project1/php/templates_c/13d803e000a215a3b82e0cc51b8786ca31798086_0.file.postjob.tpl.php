<?php
/* Smarty version 4.3.1, created on 2023-06-02 12:09:38
  from '/home/users/riya.singh/www/html/project1/php/templates/postjob.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.1',
  'unifunc' => 'content_64798eaa793719_35028993',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '13d803e000a215a3b82e0cc51b8786ca31798086' => 
    array (
      0 => '/home/users/riya.singh/www/html/project1/php/templates/postjob.tpl',
      1 => 1685686545,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_64798eaa793719_35028993 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <?php echo '<script'; ?>
 src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"><?php echo '</script'; ?>
>
    <link rel = "stylesheet" href = "../css/signin.css">
    <title>POST A JOB</title>
</head>
<body>
    <nav class = "navbar navbar-expand-sm ">
        <div class="container">
            <span class="navbar-brand">
                <img src=""><span class ="text-white">JOBSTAKE</span>
            </span>
            <span class=" justify-content-end"><a href = "../index.php"><button>BACK</button></a></span>
        </div>
    </nav>
    <div class = "formcontainer">
    <form method = "post" action = "../helper/post.php" class = "was-validated container" enctype="multipart/form-data">
    <h1 style= "text-align: center;"> POST A JOB</h1>
        <div class = "mb-3">
            <label for = "location" class = "form-label">Location: </label><br>
            <input type = "text" class = "form-control no-outline" id = "location1" placeholder = "Enter location" name = "joblocation" required>
        </div>
        <div class = "mb-3">
            <label for = "job title" class = "form-label">Job Title: </label><br>
            <input type = "text" class = "form-control no-outline" id = "title1" placeholder = "Enter job title" name = "jobtitle" required>
        </div>
        <div class = "mb-3">
            <input type = "file" name = "image" required>
        </div>
        <div class="mb-3">
            <input type = "submit" name = "submit">
        </div>
    </form>  
    <?php echo '<script'; ?>
 src = "../js/signupvalidation.js"><?php echo '</script'; ?>
>

</body>
</html><?php }
}

\$force\_cache {#variable.force.cache}
==============

This forces Smarty to (re)cache templates on every invocation. It does
not override the [`$caching`](#variable.caching) level, but merely
pretends the template has never been cached before.

<?php
class Db
{
	protected $dbhost;
	protected $dbuser;
	protected $dbpass;
	protected $dbname;
	protected static $db_object;

	public function __construct()
	{ $this->dbhost  = "localhost";
    $this->dbuser = "root";
    $this->dbpass = "webkul";
    $this->dbname = "projectdb";
		$this->connectDatabase();
	}


	protected static function _getPDO($dbhost, $dbuser, $dbpass, $dbname)
	{
		$dsn = 'mysql:host='.$dbhost.';dbname='.$dbname.'';
		return new PDO($dsn, $dbuser, $dbpass, array(PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8"));
	}

	public function connectDatabase()
	{
		try{
			self::$db_object = $this->_getPDO($this->dbhost, $this->dbuser, $this->dbpass, $this->dbname);
		} catch (PDOException $e) {
			die('Link to database cannot be established: '.$e->getMessage());
		}
	}

	public static function getDbObject()
	{
		return self::$db_object;
	}

	public static function disconnect()
	{
		self::$db_object = null;
	}

	public static function lastInsertId()
	{
		$last_inserted_id = Db::getDbobject()->lastInsertId();
		return $last_inserted_id;
	}
}
?>
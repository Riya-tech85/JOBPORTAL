<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
    class PostData{
        private $id;
        private $location;
        private $title;
        private $folder;

        function getRecord(){
            $sql = Db::getDbObject()->prepare("SELECT * FROM postjob");
            $sql->execute();
            $sqlpost = $sql->fetchAll(PDO::FETCH_ASSOC);
            return $sqlpost;
        }

        public function postjob($employername,$employerlocation,$employertitle,$employeremail,$publish,$folder){
            $sql =Db::getDbObject()->prepare("INSERT INTO postjob ( employer_name,employer_location, employer_jobtitle, employer_email,img,publish) value (:employername,:joblocation,:jobtitle,:jobemail,:img,:publish)");
            $sql->bindValue(':employername',$employername);
            $sql->bindValue(':joblocation',$employerlocation);
            $sql->bindValue(':jobtitle',$employertitle);
            $sql->bindValue(':jobemail',$employeremail );
            $sql->bindValue(':publish',$publish );
            $sql->bindValue(':img',$folder );
            $sql->execute();

            $latestid = Db::getDbobject()->lastInsertId();
            $_SESSION['id'] = $latestid;
        }

        public function getpostid(){
            $sql = Db::getDbObject()->prepare("SELECT * FROM postjob where id = :id");
            $sql->bindValue(':id',$_SESSION['id']);
            $sql->execute();
            $sqlpost = $sql->fetch(PDO::FETCH_ASSOC);
            return $sqlpost;
        }

        public function getpostid1($id){
            $sql = Db::getDbObject()->prepare("SELECT * FROM postjob where id = :id");
            $sql->bindValue(':id',$id);
            $sql->execute();
            $sqlpost = $sql->fetch(PDO::FETCH_ASSOC);
            return $sqlpost;
        }

        public function publishbutton($id){
            $sql = Db::getDbObject()->prepare("UPDATE postjob SET publish = 1 where id = :id");
            $sql->bindValue(':id',$id,PDO::PARAM_INT);
            $sql->execute();
        }

        public function publishbuttonoff($id){
            $sql = Db::getDbObject()->prepare("UPDATE postjob SET publish = 0 where id = :id");
            $sql->bindValue(':id',$id,PDO::PARAM_INT);
            $sql->execute();
        }

        public function updatepostdata($location,$title,$folder,$id){        
            $sql = Db::getDbObject()->prepare("UPDATE postjob SET employer_location = :location1 , employer_jobtitle = :title , img = :image1 where id = :id ");
            $sql->bindValue(':location1',$location);
            $sql->bindValue(':title',$title);
            $sql->bindValue(':image1',$folder);
            $sql->bindValue(':id',$id,PDO::PARAM_INT);
            $sql->execute();

        }

        public function search($search){
            $sql = "SELECT * FROM postjob WHERE employer_jobtitle LIKE :search";
            $smt = Db::getDbObject()->prepare($sql);
            $smt->bindValue(':search',"%$search%",PDO::PARAM_STR);
            $smt->execute();
            $result = $smt->fetchAll(PDO::FETCH_ASSOC);
            return $result;
        }
    }
?>